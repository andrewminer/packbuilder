import mcpacker.model.resourcepack.kind


# Tests ############################################################################################

def test_syntax():
    pass
