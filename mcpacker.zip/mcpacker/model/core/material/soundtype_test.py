import mcpacker.model.core.material.soundtype


# Tests ############################################################################################

def test_syntax():
    pass
