import mcpacker.model.mod


# Tests ############################################################################################

def test_syntax():
    pass
