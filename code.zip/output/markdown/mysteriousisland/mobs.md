# Mob: armadillo <minecraft:armadillo>

  * habitat 1
    * altitude: lowlands
    * biomeFilter:
      * Heat: subtropical
      * Humidity: dry
    * seasons: summer
    * group: solo-pair
    * location: outside
    * scarcity: common
  * habitat 2
    * altitude: uplands
    * biomeFilter:
      * Heat: subtropical
      * Humidity: dry
    * seasons: summer
    * group: solo-pair
    * location: outside
    * scarcity: sparse
  * habitat 3
    * altitude: lowlands
    * biomeFilter:
      * Heat: subtropical
      * Humidity: dry
    * seasons: spring, autumn, winter
    * group: solo-pair
    * location: outside
    * scarcity: uncommon
  * habitat 4
    * altitude: uplands
    * biomeFilter:
      * Heat: subtropical
      * Humidity: dry
    * seasons: spring, autumn, winter
    * group: solo-pair
    * location: outside
    * scarcity: unusual

# Mob: black_bear <bearminimum:black_bear>

  * habitat 1
    * altitude: lowlands-alpine
    * biomeFilter:
      * Heat: temperate
      * Flora: forest
    * seasons: autumn
    * group: solo-family
    * location: outside
    * scarcity: uncommon
  * habitat 2
    * altitude: lowlands-alpine
    * biomeFilter:
      * Heat: temperate
      * Flora: forest
    * seasons: spring, summer
    * group: solo-family
    * location: outside
    * scarcity: sparse
  * habitat 3
    * altitude: lowlands-alpine
    * biomeFilter:
      * Heat: temperate
      * Flora: forest
    * seasons: winter
    * group: solo-family
    * location: outside
    * scarcity: unusual
  * habitat 4
    * altitude: lowlands-alpine
    * biomeFilter:
      * Heat: boreal
      * Flora: any of: canopy, forest
    * seasons: autumn
    * group: solo-family
    * location: outside
    * scarcity: sparse
  * habitat 5
    * altitude: lowlands-alpine
    * biomeFilter:
      * Heat: boreal
      * Flora: any of: canopy, forest
    * seasons: spring, summer
    * group: solo-family
    * location: outside
    * scarcity: unusual
  * habitat 6
    * altitude: lowlands-alpine
    * biomeFilter:
      * Heat: boreal
      * Flora: any of: canopy, forest
    * seasons: winter
    * group: solo-family
    * location: outside
    * scarcity: rare

# Mob: blaze <minecraft:blaze>

  * habitat 1
    * altitude: plutonic
    * biomeFilter:
    * seasons: spring, summer, autumn, winter
    * group: solo
    * location: cave
    * scarcity: uncommon

# Mob: bogged <minecraft:bogged>


# Mob: brown_bear <bearminimum:brown_bear>

  * habitat 1
    * altitude: lowlands-alpine
    * biomeFilter:
      * Heat: boreal
      * Flora: any of: canopy, forest
    * seasons: autumn
    * group: solo
    * location: outside
    * scarcity: sparse
  * habitat 2
    * altitude: lowlands-alpine
    * biomeFilter:
      * Heat: boreal
      * Flora: any of: canopy, forest
    * seasons: spring, summer
    * group: solo
    * location: outside
    * scarcity: unusual
  * habitat 3
    * altitude: lowlands-alpine
    * biomeFilter:
      * Heat: boreal
      * Flora: any of: canopy, forest
    * seasons: winter
    * group: solo
    * location: outside
    * scarcity: rare

# Mob: bulwark <immersiveengineering:bulwark>


# Mob: camel <minecraft:camel>

  * habitat 1
    * altitude: dunes-lowlands
    * biomeFilter:
      * Heat: tropical
      * Humidity: dry
      * Flora: barren
      * Soil: sandy
    * seasons: summer, autumn
    * group: family
    * location: outside
    * scarcity: unusual
  * habitat 2
    * altitude: dunes-lowlands
    * biomeFilter:
      * Heat: tropical
      * Humidity: dry
      * Flora: barren
      * Soil: sandy
    * seasons: winter, spring
    * group: family
    * location: outside
    * scarcity: rare

# Mob: cat <minecraft:cat>


# Mob: cave_spider <minecraft:cave_spider>

  * habitat 1
    * altitude: overburden-hills
    * biomeFilter:
    * seasons: spring, summer, autumn, winter
    * group: solo
    * location: cave
    * scarcity: uncommon

# Mob: chameleon <cold_sweat:chameleon>

  * habitat 1
    * altitude: dunes-uplands
    * biomeFilter:
      * Heat: tropical
      * Humidity: wet
      * Flora: any of: canopy, forest
    * seasons: winter, spring
    * group: solo-family
    * location: outside
    * scarcity: common
  * habitat 2
    * altitude: dunes-uplands
    * biomeFilter:
      * Heat: tropical
      * Humidity: wet
      * Flora: any of: canopy, forest
    * seasons: summer, autumn
    * group: solo-family
    * location: outside
    * scarcity: uncommon
  * habitat 3
    * altitude: dunes-uplands
    * biomeFilter:
      * Heat: tropical
      * Humidity: wet
      * Flora: clearing
    * seasons: winter, spring
    * group: solo-family
    * location: outside
    * scarcity: uncommon
  * habitat 4
    * altitude: dunes-uplands
    * biomeFilter:
      * Heat: tropical
      * Humidity: wet
      * Flora: clearing
    * seasons: summer, autumn
    * group: solo-family
    * location: outside
    * scarcity: sparse

# Mob: chicken <minecraft:chicken>

  * habitat 1
    * altitude: lowlands-uplands
    * biomeFilter:
      * Heat: tropical
      * Humidity: wet
      * Flora: any of: canopy, forest, clearing
    * seasons: summer
    * group: troup
    * location: outside
    * scarcity: common
  * habitat 2
    * altitude: lowlands-uplands
    * biomeFilter:
      * Heat: tropical
      * Humidity: wet
      * Flora: any of: canopy, forest, clearing
    * seasons: spring, autumn, winter
    * group: troup
    * location: outside
    * scarcity: uncommon

# Mob: cod <minecraft:cod>


# Mob: commando <immersiveengineering:commando>


# Mob: cow <minecraft:cow>


# Mob: crab <crabbersdelight:crab>


# Mob: creeper <minecraft:creeper>


# Mob: dolphin <minecraft:dolphin>


# Mob: donkey <minecraft:donkey>


# Mob: drowned <minecraft:drowned>


# Mob: enderman <minecraft:enderman>


# Mob: evoker <minecraft:evoker>


# Mob: fox <minecraft:fox>


# Mob: frog <minecraft:frog>


# Mob: fusilier <immersiveengineering:fusilier>


# Mob: glow_squid <minecraft:glow_squid>


# Mob: goat <minecraft:goat>


# Mob: hoglin <minecraft:hoglin>


# Mob: horse <minecraft:horse>


# Mob: husk <minecraft:husk>


# Mob: llama <minecraft:llama>


# Mob: magma_cube <minecraft:magma_cube>


# Mob: mooshroom <minecraft:mooshroom>


# Mob: mule <minecraft:mule>


# Mob: ocelot <minecraft:ocelot>


# Mob: panda <minecraft:panda>


# Mob: parrot <minecraft:parrot>


# Mob: pig <minecraft:pig>


# Mob: pillager <minecraft:pillager>


# Mob: polar_bear <minecraft:polar_bear>


# Mob: pufferfish <minecraft:pufferfish>


# Mob: rabbit <minecraft:rabbit>


# Mob: raccoon <animalplus:raccoon>


# Mob: ravager <minecraft:ravager>


# Mob: red_panda <animalplus:red_panda>


# Mob: salmon <minecraft:salmon>


# Mob: sheep <minecraft:sheep>


# Mob: skeleton <minecraft:skeleton>


# Mob: slime <minecraft:slime>


# Mob: spider <minecraft:spider>


# Mob: squid <minecraft:squid>


# Mob: tropical_fish <minecraft:tropical_fish>


# Mob: turtle <minecraft:turtle>


# Mob: vex <minecraft:vex>


# Mob: villager <minecraft:villager>


# Mob: vindicator <minecraft:vindicator>


# Mob: wandering_trader <minecraft:wandering_trader>


# Mob: warden <minecraft:warden>


# Mob: witch <minecraft:witch>


# Mob: wither_skeleton <minecraft:wither_skeleton>


# Mob: wither <minecraft:wither>


# Mob: wolf <minecraft:wolf>


# Mob: zoglin <minecraft:zoglin>


# Mob: zombie_villager <minecraft:zombie_villager>


# Mob: zombie <minecraft:zombie>