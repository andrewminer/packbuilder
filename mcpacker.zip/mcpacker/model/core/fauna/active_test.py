from pytest import fixture

import mcpacker.model.core.fauna.active as active


# Tests ############################################################################################

def test_syntax():
    pass
