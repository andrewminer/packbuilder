import mcpacker.pack.mysteriousisland.datapack


# Tests ############################################################################################

def test_syntax():
    pass
