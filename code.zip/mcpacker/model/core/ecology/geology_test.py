from pytest import fixture

import mcpacker.model.core.ecology.geology as geology


# Tests ############################################################################################

def test_syntax():
    pass
