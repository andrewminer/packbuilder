import mcpacker.pack.mysteriousisland.mineralcatalog


# Class ############################################################################################

def test_syntax():
    pass
