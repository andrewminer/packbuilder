import mcpacker.pack.mysteriousisland.resourcepack


# Tests ############################################################################################

def test_syntax():
    pass
