import mcpacker.model.core.material.loot


# Tests ############################################################################################

def test_syntax():
    pass
