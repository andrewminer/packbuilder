import mcpacker.model.core.material.item


# Tests ############################################################################################

def test_syntax():
    pass
