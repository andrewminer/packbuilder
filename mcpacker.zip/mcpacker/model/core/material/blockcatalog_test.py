import mcpacker.model.core.material.blockcatalog


# Tests ############################################################################################

def test_syntax():
    pass
