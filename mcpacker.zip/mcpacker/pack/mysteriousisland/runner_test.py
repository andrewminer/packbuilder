import mcpacker.pack.mysteriousisland.runner


# Tests ############################################################################################

def test_syntax():
    pass
