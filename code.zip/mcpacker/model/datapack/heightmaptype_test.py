from mcpacker.model.datapack.heightmaptype import HeightMapType


# Tests ############################################################################################

def test_syntax():
    pass
