import mcpacker.pack.mysteriousisland.blockcatalog


# Class ############################################################################################

def test_syntax():
    pass
