from pytest import fixture

import mcpacker.model.core.ecology.soil as soil


# Tests ############################################################################################

def test_syntax():
    pass
