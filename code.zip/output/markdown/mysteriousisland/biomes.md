# Biome: aberdeen <minecraft:windswept_gravelly_hills>

  * Flora: barren
  * Geology: metamorphic
  * Heat: boreal
  * Humidity: damp
  * Soil: rocky
  * Water: inland

# Biome: archangel <minecraft:frozen_ocean>

  * Flora: barren
  * Geology: sedimentary
  * Heat: frozen
  * Humidity: wet
  * Soil: sandy
  * Water: ocean

# Biome: aspen <minecraft:frozen_peaks>

  * Flora: barren
  * Geology: igneous
  * Heat: frozen
  * Humidity: wet
  * Soil: rocky
  * Water: inland

# Biome: bombay <minecraft:lukewarm_ocean>

  * Flora: barren
  * Geology: sedimentary
  * Heat: subtropical
  * Humidity: wet
  * Soil: sandy
  * Water: ocean

# Biome: boston <minecraft:cold_ocean>

  * Flora: barren
  * Geology: sedimentary
  * Heat: boreal
  * Humidity: wet
  * Soil: clayey
  * Water: ocean

# Biome: bryce <minecraft:eroded_badlands>

  * Flora: barren
  * Geology: sedimentary
  * Heat: subtropical
  * Humidity: dry
  * Soil: clayey
  * Water: inland

# Biome: calcutta <minecraft:mangrove_swamp>

  * Flora: forest
  * Geology: sedimentary
  * Heat: subtropical
  * Humidity: wet
  * Soil: clayey
  * Water: inland

# Biome: cornwall <minecraft:windswept_hills>

  * Flora: barren
  * Geology: metamorphic
  * Heat: boreal
  * Humidity: damp
  * Soil: rocky
  * Water: inland

# Biome: dallas <minecraft:savanna>

  * Flora: field
  * Geology: sedimentary
  * Heat: subtropical
  * Humidity: dry
  * Soil: sandy
  * Water: inland

# Biome: duluth <minecraft:frozen_river>

  * Flora: barren
  * Geology: sedimentary
  * Heat: frozen
  * Humidity: wet
  * Soil: sandy
  * Water: river

# Biome: durango <minecraft:savanna_plateau>

  * Flora: field
  * Geology: igneous
  * Heat: subtropical
  * Humidity: dry
  * Soil: sandy
  * Water: inland

# Biome: freiburg <minecraft:dark_forest>

  * Flora: canopy
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: wet
  * Soil: clayey
  * Water: inland

# Biome: glasgow <minecraft:windswept_forest>

  * Flora: clearing
  * Geology: metamorphic
  * Heat: boreal
  * Humidity: damp
  * Soil: acidic
  * Water: inland

# Biome: haarlem <minecraft:flower_forest>

  * Flora: clearing
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: damp
  * Soil: loamy
  * Water: inland

# Biome: halifax <minecraft:deep_cold_ocean>

  * Flora: barren
  * Geology: sedimentary
  * Heat: boreal
  * Humidity: wet
  * Soil: sandy
  * Water: ocean

# Biome: hammerfest <minecraft:ice_spikes>

  * Flora: barren
  * Geology: metamorphic
  * Heat: frozen
  * Humidity: wet
  * Soil: rocky
  * Water: inland

# Biome: havana <minecraft:deep_lukewarm_ocean>

  * Flora: barren
  * Geology: sedimentary
  * Heat: subtropical
  * Humidity: wet
  * Soil: sandy
  * Water: ocean

# Biome: hilo <minecraft:mushroom_fields>

  * Flora: clearing
  * Geology: igneous
  * Heat: subtropical
  * Humidity: wet
  * Soil: fungal
  * Water: inland

# Biome: honolulu <minecraft:deep_ocean>

  * Flora: barren
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: wet
  * Soil: sandy
  * Water: ocean

# Biome: innnesbruk <minecraft:meadow>

  * Flora: field
  * Geology: sedimentary
  * Heat: boreal
  * Humidity: damp
  * Soil: peaty
  * Water: inland

# Biome: irkutsk <minecraft:taiga>

  * Flora: forest
  * Geology: metamorphic
  * Heat: boreal
  * Humidity: damp
  * Soil: acidic
  * Water: inland

# Biome: jackson <minecraft:jagged_peaks>

  * Flora: barren
  * Geology: metamorphic
  * Heat: boreal
  * Humidity: dry
  * Soil: rocky
  * Water: inland

# Biome: juneau <minecraft:old_growth_spruce_taiga>

  * Flora: forest
  * Geology: metamorphic
  * Heat: boreal
  * Humidity: damp
  * Soil: peaty
  * Water: inland

# Biome: kansascity <minecraft:plains>

  * Flora: field
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: damp
  * Soil: loamy
  * Water: inland

# Biome: kola <minecraft:snowy_taiga>

  * Flora: barren
  * Geology: metamorphic
  * Heat: frozen
  * Humidity: damp
  * Soil: acidic
  * Water: inland

# Biome: kyoto <minecraft:cherry_grove>

  * Flora: clearing
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: damp
  * Soil: rocky
  * Water: inland

# Biome: madras <minecraft:sparse_jungle>

  * Flora: clearing
  * Geology: sedimentary
  * Heat: tropical
  * Humidity: wet
  * Soil: acidic
  * Water: inland

# Biome: memphis <minecraft:river>

  * Flora: clearing
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: wet
  * Soil: sandy
  * Water: river

# Biome: minsk <minecraft:old_growth_birch_forest>

  * Flora: forest
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: damp
  * Soil: acidic
  * Water: inland

# Biome: moab <minecraft:windswept_savanna>

  * Flora: field
  * Geology: igneous
  * Heat: subtropical
  * Humidity: dry
  * Soil: rocky
  * Water: inland

# Biome: mobile <minecraft:swamp>

  * Flora: clearing
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: wet
  * Soil: peaty
  * Water: swamp

# Biome: moscow <minecraft:snowy_plains>

  * Flora: field
  * Geology: sedimentary
  * Heat: frozen
  * Humidity: damp
  * Soil: loamy
  * Water: inland

# Biome: nassau <minecraft:warm_ocean>

  * Flora: barren
  * Geology: sedimentary
  * Heat: tropical
  * Humidity: wet
  * Soil: sandy
  * Water: coast

# Biome: nice <minecraft:beach>

  * Flora: barren
  * Geology: sedimentary
  * Heat: subtropical
  * Humidity: damp
  * Soil: sandy
  * Water: coast

# Biome: nuuk <minecraft:beach>

  * Flora: barren
  * Geology: sedimentary
  * Heat: frozen
  * Humidity: damp
  * Soil: sandy
  * Water: coast

# Biome: perm <minecraft:old_growth_pine_taiga>

  * Flora: forest
  * Geology: metamorphic
  * Heat: boreal
  * Humidity: damp
  * Soil: acidic
  * Water: inland

# Biome: phoenix <minecraft:desert>

  * Flora: barren
  * Geology: sedimentary
  * Heat: tropical
  * Humidity: dry
  * Soil: sandy
  * Water: inland

# Biome: plymouth <minecraft:stony_shore>

  * Flora: barren
  * Geology: metamorphic
  * Heat: temperate
  * Humidity: damp
  * Soil: rocky
  * Water: coast

# Biome: portland <minecraft:forest>

  * Flora: forest
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: damp
  * Soil: loamy
  * Water: inland

# Biome: quito <minecraft:stony_peaks>

  * Flora: barren
  * Geology: igneous
  * Heat: boreal
  * Humidity: dry
  * Soil: rocky
  * Water: inland

# Biome: rangoon <minecraft:bamboo_jungle>

  * Flora: barren
  * Geology: sedimentary
  * Heat: subtropical
  * Humidity: dry
  * Soil: loamy
  * Water: inland

# Biome: sanfrancisco <minecraft:ocean>

  * Flora: barren
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: wet
  * Soil: sandy
  * Water: ocean

# Biome: santafe <minecraft:wooded_badlands>

  * Flora: clearing
  * Geology: sedimentary
  * Heat: subtropical
  * Humidity: dry
  * Soil: clayey
  * Water: inland

# Biome: singapore <minecraft:jungle>

  * Flora: canopy
  * Geology: sedimentary
  * Heat: tropical
  * Humidity: wet
  * Soil: acidic
  * Water: inland

# Biome: tombstone <minecraft:badlands>

  * Flora: barren
  * Geology: sedimentary
  * Heat: subtropical
  * Humidity: dry
  * Soil: clayey
  * Water: inland

# Biome: topeka <minecraft:sunflower_plains>

  * Flora: field
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: damp
  * Soil: loamy
  * Water: inland

# Biome: tromso <minecraft:deep_frozen_ocean>

  * Flora: barren
  * Geology: sedimentary
  * Heat: frozen
  * Humidity: wet
  * Soil: sandy
  * Water: ocean

# Biome: umea <minecraft:grove>

  * Flora: clearing
  * Geology: metamorphic
  * Heat: frozen
  * Humidity: damp
  * Soil: acidic
  * Water: inland

# Biome: warsaw <minecraft:birch_forest>

  * Flora: forest
  * Geology: sedimentary
  * Heat: temperate
  * Humidity: damp
  * Soil: acidic
  * Water: inland

# Biome: zurich <minecraft:snowy_slopes>

  * Flora: barren
  * Geology: metamorphic
  * Heat: frozen
  * Humidity: damp
  * Soil: rocky
  * Water: inland