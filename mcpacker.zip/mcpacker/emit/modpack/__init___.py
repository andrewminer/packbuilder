from mcpacker.model.core.modpack
