from mcpacker.model.modpack  import ModPack
from mcpacker.model.datapack import DataPack


# Functions ########################################################################################

def addDataPack(modPack:ModPack):
    pass
