import mcpacker.model.resourcepack.mod


# Tests ############################################################################################

def test_syntax():
    pass

