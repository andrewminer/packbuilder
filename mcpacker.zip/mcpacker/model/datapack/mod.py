# Class ############################################################################################

class Mod:

    def __init__(self):
        self.biomeModifiers = []
        self.configuredFeatures = []
        self.functions = []
        self.functionTags = []
        self.lootModifiers = []
        self.lootTables = []
        self.placedFeatures = []
        self.recipes = []
        self.structures = []
        self.structureSets = []
        self.tags = []
        self.templatePools = []
