import mcpacker.model.core.material.loottable


# Tests ############################################################################################

def test_syntax():
    pass
