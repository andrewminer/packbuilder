from mcpacker.model.datapack.placedfeature import PlacedFeature


# Tests ############################################################################################

def test_syntax():
    pass
