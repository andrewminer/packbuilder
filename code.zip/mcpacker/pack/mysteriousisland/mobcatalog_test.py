import mcpacker.pack.mysteriousisland.mobcatalog


# Class ############################################################################################

def test_syntax():
    pass
