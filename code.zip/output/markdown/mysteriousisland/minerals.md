# Mineral: coal

  * #minecraft:stone_ore_replaceables => minecraft:coal_ore
  * #minecraft:deepslate_ore_replaceables => minecraft:deepslate_coal_ore

# Mineral: copper

  * #minecraft:stone_ore_replaceables => minecraft:copper_ore
  * #minecraft:deepslate_ore_replaceables => minecraft:deepslate_copper_ore

# Mineral: diamond

  * #minecraft:stone_ore_replaceables => minecraft:diamond_ore
  * #minecraft:deepslate_ore_replaceables => minecraft:deepslate_diamond_ore

# Mineral: emerald

  * #minecraft:stone_ore_replaceables => minecraft:emerald_ore
  * #minecraft:deepslate_ore_replaceables => minecraft:deepslate_emerald_ore

# Mineral: gold

  * #minecraft:stone_ore_replaceables => minecraft:gold_ore
  * #minecraft:deepslate_ore_replaceables => minecraft:deepslate_gold_ore

# Mineral: iron

  * #minecraft:stone_ore_replaceables => minecraft:iron_ore
  * #minecraft:deepslate_ore_replaceables => minecraft:deepslate_iron_ore

# Mineral: lapis

  * #minecraft:stone_ore_replaceables => minecraft:lapis_ore
  * #minecraft:deepslate_ore_replaceables => minecraft:deepslate_lapis_ore

# Mineral: redstone

  * #minecraft:stone_ore_replaceables => minecraft:redstone_ore
  * #minecraft:deepslate_ore_replaceables => minecraft:deepslate_redstone_ore

# Mineral: amethyst

  * #minecraft:stone_ore_replaceables => minecraft:amethyst_block
  * #minecraft:deepslate_ore_replaceables => minecraft:amethyst_block

# Mineral: glowstone

  * #minecraft:stone_ore_replaceables => minecraft:glowstone
  * #minecraft:deepslate_ore_replaceables => minecraft:glowstone

# Mineral: quartz

  * #minecraft:stone_ore_replaceables => overworldquartzore:quartz_ore
  * #minecraft:deepslate_ore_replaceables => overworldquartzore:quartz_ore

# Mineral: salt

  * #minecraft:stone_ore_replaceables => butcher:saltblock
  * #minecraft:deepslate_ore_replaceables => butcher:saltblock

# Mineral: clay

  * #minecraft:stone_ore_replaceables => minecraft:clay
  * #minecraft:deepslate_ore_replaceables => minecraft:clay

# Mineral: coarsedirt

  * #minecraft:stone_ore_replaceables => minecraft:coarse_dirt
  * #minecraft:deepslate_ore_replaceables => minecraft:coarse_dirt

# Mineral: dirt

  * #minecraft:stone_ore_replaceables => minecraft:dirt
  * #minecraft:deepslate_ore_replaceables => minecraft:dirt

# Mineral: gravel

  * #minecraft:stone_ore_replaceables => minecraft:gravel
  * #minecraft:deepslate_ore_replaceables => minecraft:gravel

# Mineral: loam

  * #minecraft:stone_ore_replaceables => farmersdelight:rich_soil
  * #minecraft:deepslate_ore_replaceables => farmersdelight:rich_soil

# Mineral: packedice

  * #minecraft:stone_ore_replaceables => minecraft:packed_ice
  * #minecraft:deepslate_ore_replaceables => minecraft:packed_ice

# Mineral: peat

  * #minecraft:stone_ore_replaceables => kubejs:peat_block
  * #minecraft:deepslate_ore_replaceables => kubejs:peat_block

# Mineral: redsand

  * #minecraft:stone_ore_replaceables => minecraft:redsand
  * #minecraft:deepslate_ore_replaceables => minecraft:redsand

# Mineral: sand

  * #minecraft:stone_ore_replaceables => minecraft:sand
  * #minecraft:deepslate_ore_replaceables => minecraft:sand

# Mineral: soulsand

  * #minecraft:stone_ore_replaceables => minecraft:soulsand
  * #minecraft:deepslate_ore_replaceables => minecraft:soulsand

# Mineral: andesite

  * #minecraft:stone_ore_replaceables => minecraft:andesite
  * #minecraft:deepslate_ore_replaceables => minecraft:andesite

# Mineral: arkrose

  * #minecraft:stone_ore_replaceables => minecraft:red_sandstone
  * #minecraft:deepslate_ore_replaceables => minecraft:red_sandstone

# Mineral: basalt

  * #minecraft:stone_ore_replaceables => minecraft:basalt
  * #minecraft:deepslate_ore_replaceables => minecraft:basalt

# Mineral: breccia

  * #minecraft:stone_ore_replaceables => minecraft:cobblestone
  * #minecraft:deepslate_ore_replaceables => minecraft:cobblestone

# Mineral: chalk

  * #minecraft:stone_ore_replaceables => minecraft:calcite
  * #minecraft:deepslate_ore_replaceables => minecraft:calcite

# Mineral: diorite

  * #minecraft:stone_ore_replaceables => minecraft:diorite
  * #minecraft:deepslate_ore_replaceables => minecraft:diorite

# Mineral: dolostone

  * #minecraft:stone_ore_replaceables => minecraft:end_stone
  * #minecraft:deepslate_ore_replaceables => minecraft:end_stone

# Mineral: gneiss

  * #minecraft:stone_ore_replaceables => minecraft:deepslate
  * #minecraft:deepslate_ore_replaceables => minecraft:deepslate

# Mineral: granite

  * #minecraft:stone_ore_replaceables => minecraft:granite
  * #minecraft:deepslate_ore_replaceables => minecraft:granite

# Mineral: greywacke

  * #minecraft:stone_ore_replaceables => minecraft:stone
  * #minecraft:deepslate_ore_replaceables => minecraft:stone

# Mineral: komatite

  * #minecraft:stone_ore_replaceables => minecraft:blackstone
  * #minecraft:deepslate_ore_replaceables => minecraft:blackstone

# Mineral: limestone

  * #minecraft:stone_ore_replaceables => minecraft:dripstone_block
  * #minecraft:deepslate_ore_replaceables => minecraft:dripstone_block

# Mineral: magma

  * #minecraft:stone_ore_replaceables => minecraft:magma_block
  * #minecraft:deepslate_ore_replaceables => minecraft:magma_block

# Mineral: marble

  * #minecraft:stone_ore_replaceables => railcraft:quarried_stone
  * #minecraft:deepslate_ore_replaceables => railcraft:quarried_stone

# Mineral: netherite

  * #minecraft:stone_ore_replaceables => minecraft:ancient_debris
  * #minecraft:deepslate_ore_replaceables => minecraft:ancient_debris

# Mineral: obsidian

  * #minecraft:stone_ore_replaceables => minecraft:obsidian
  * #minecraft:deepslate_ore_replaceables => minecraft:obsidian

# Mineral: pumice

  * #minecraft:stone_ore_replaceables => minecraft:netherrack
  * #minecraft:deepslate_ore_replaceables => minecraft:netherrack

# Mineral: sandstone

  * #minecraft:stone_ore_replaceables => minecraft:sandstone
  * #minecraft:deepslate_ore_replaceables => minecraft:sandstone

# Mineral: tuff

  * #minecraft:stone_ore_replaceables => minecraft:tuff
  * #minecraft:deepslate_ore_replaceables => minecraft:tuff

# Mineral: aluminum

  * #minecraft:stone_ore_replaceables => immersiveengineering:ore_aluminum
  * #minecraft:deepslate_ore_replaceables => {IE}:deepslate_ore_{name}

# Mineral: lead

  * #minecraft:stone_ore_replaceables => immersiveengineering:ore_lead
  * #minecraft:deepslate_ore_replaceables => {IE}:deepslate_ore_{name}

# Mineral: nickel

  * #minecraft:stone_ore_replaceables => immersiveengineering:ore_nickel
  * #minecraft:deepslate_ore_replaceables => {IE}:deepslate_ore_{name}

# Mineral: silver

  * #minecraft:stone_ore_replaceables => immersiveengineering:ore_silver
  * #minecraft:deepslate_ore_replaceables => {IE}:deepslate_ore_{name}

# Mineral: uranium

  * #minecraft:stone_ore_replaceables => immersiveengineering:ore_uranium
  * #minecraft:deepslate_ore_replaceables => {IE}:deepslate_ore_{name}

# Mineral: saltpeter

  * minecraft:sand => railcraft:saltpeter_ore
  * minecraft:sandstone => railcraft:saltpeter_ore

# Mineral: sulfur

  * #minecraft:stone_ore_replaceables => railcraft:sulfur_ore
  * #minecraft:deepslate_ore_replaceables => {RC}:deepslate_{name}_ore

# Mineral: tin

  * #minecraft:stone_ore_replaceables => railcraft:tin_ore
  * #minecraft:deepslate_ore_replaceables => {RC}:deepslate_{name}_ore

# Mineral: zinc

  * #minecraft:stone_ore_replaceables => railcraft:zinc_ore
  * #minecraft:deepslate_ore_replaceables => {RC}:deepslate_{name}_ore