from mcpacker.model.core.world import World


# Tests ############################################################################################

def test_syntax():
    pass
