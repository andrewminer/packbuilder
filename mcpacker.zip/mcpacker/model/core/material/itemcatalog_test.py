import mcpacker.model.core.material.itemcatalog


# Tests ############################################################################################

def test_syntax():
    pass
