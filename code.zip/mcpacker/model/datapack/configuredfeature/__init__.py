# Class ############################################################################################

class ConfiguredFeature:

    def __init__(self, gameId:str):
        self.gameId = gameId
