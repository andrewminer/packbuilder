from mcpacker.model.modpack      import ModPack
from mcpacker.model.resourcepack import ResourcePack


# Functions ########################################################################################

def addResourcePack(modPack:ModPack):
    pass
