import mcpacker.pack.mysteriousisland.modpack


# Tests ############################################################################################

def test_syntax():
    pass
