from mcpacker.model.core.scarcity import Scarcity
from pytest import fixture


# Tests ############################################################################################

def test_syntax():
    pass
