import mcpacker.model.modpack


# Tests ############################################################################################

def test_syntax():
    pass
