from pytest import fixture

import mcpacker.model.core.ecology.water as water


# Tests ############################################################################################

def test_syntax():
    pass
