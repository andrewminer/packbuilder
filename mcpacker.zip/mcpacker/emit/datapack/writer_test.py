import mcpacker.emit.datapack.writer


# Tests ############################################################################################

def test_syntax():
    pass
