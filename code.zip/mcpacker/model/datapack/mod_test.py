import mcpacker.model.datapack.mod


# Tests ############################################################################################

def test_syntax():
    pass
