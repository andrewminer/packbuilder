# Class ############################################################################################

class BlockStateProvider:

    def __init__(self, gameId:str):
        self.gameId = gameId

