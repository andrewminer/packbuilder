import mcpacker.model.core.material.block

# Tests ############################################################################################

def test_syntax():
    pass
