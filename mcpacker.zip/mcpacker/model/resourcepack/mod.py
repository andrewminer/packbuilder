# Class ############################################################################################

class Mod:

    def __init__(self):
        self.blockStates = []
        self.models = []
        self.textures = []
