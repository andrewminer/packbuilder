import mcpacker.pack.mysteriousisland.biomecatalog


# Class ############################################################################################

def test_syntax():
    pass
