import mcpacker.model.resourcepack.texture


# Tests ############################################################################################

def test_syntax():
    pass
